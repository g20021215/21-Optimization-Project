function B = B(a)
    if bin == 0
        B = 0;
    end
    if bin ~= 0
        B = a;
    end
end
