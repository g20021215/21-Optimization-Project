function  f = floo(s) % This function is used to get the number of the Wi in the draft 
    if s > 0 || s <= 1
        b = 0.1
    if s > 1
        b = 0.1 * (1 + floor(s))*floor(s) + 0.1
end