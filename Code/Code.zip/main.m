[x,fval,exitflag] = fmincon('obj',[1,2],[],[],[],[],[],[],'constrain');
x;
fval;
exitflag;
